package sistema_gestao_agro.service;

import java.util.List;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import sistema_gestao_agro.dto.UserDTO;
import sistema_gestao_agro.dto.UserResponseDTO;
import sistema_gestao_agro.mapper.UserMapper;
import sistema_gestao_agro.model.User;
import sistema_gestao_agro.repository.UserRepository;

@Service
public class UserService {
     //injeção de dependência do UserRepository
    private final UserRepository repository;
    private final PasswordEncoder passwordEncoder;
    
    //construtor para injetar o UserRepository e o PasswordEncoder
    public UserService(UserRepository repository, PasswordEncoder passwordEncoder) {
        this.repository = repository;
        this.passwordEncoder = passwordEncoder;
    }

    public User criar(UserDTO dto) {
        User user = new User();
        user.setName(dto.getName());
        user.setEmail(dto.getEmail());
        user.setRole(dto.getRole());
        user.setActive(true);
        user.setPassword(passwordEncoder.encode(dto.getPassword())); // Criptografa a senha

        return repository.save(user);
    }


   


    //método para atualizar um usuário existente
    public User atualizar(User user) {
        return repository.save(user);
    }



    //método para listar todos os usuários
    public List<User> listar(){
        return repository.findAll();
    }
    
    public UserResponseDTO buscarPorId(Long id) {
        User user = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        return UserMapper.toResponseDTO(user);
    }

    public User buscarEntidadePorId(Long id) {
        return repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));


    
}

public void deletar(Long id) {

    User user = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

    repository.delete(user);
}

  
}
