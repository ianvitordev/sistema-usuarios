package Sistema_Gestao_Agro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaGestaoAgroApplicationTests {

	@Test
	void contextLoads() {
	}

}
