package sistema_gestao_agro.security;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import sistema_gestao_agro.dto.LoginDTO;
import sistema_gestao_agro.dto.RegisterDTO;
import sistema_gestao_agro.model.User;
import sistema_gestao_agro.repository.UserRepository;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthenticationController {

    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginDTO dto) {

        System.out.println("Entrou no login");
        System.out.println(dto.getEmail());

        var authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        dto.getEmail(),
                        dto.getPassword()
                )
        );

        User user = userRepository.findByEmail(authentication.getName()).get();

        String token = jwtService.generateToken(
        user.getEmail(),
        user.getRole().name()
);

        return ResponseEntity.ok(token);
    }

    @PreAuthorize("hasRole('ADMIN')") // Somente usuários com papel ADMIN podem acessar este endpoint
    @PostMapping("/register")
public ResponseEntity<String> register(@RequestBody RegisterDTO dto) {

    String encryptedPassword = passwordEncoder.encode(dto.getPassword());

    User user = new User();
    user.setEmail(dto.getEmail());
    user.setPassword(encryptedPassword);
    user.setRole(User.Role.USER); // Define o papel padrão como USER

    userRepository.save(user);

    return ResponseEntity.ok("Usuário criado com sucesso");
}

@PreAuthorize("hasRole('ADMIN')")
@PatchMapping("/users/{id}/active")
public ResponseEntity<String> toggleUser(@PathVariable Long id) {

    User user = userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

    user.setActive(!user.getActive());

    userRepository.save(user);

    return ResponseEntity.ok("Status alterado com sucesso");
}

@PreAuthorize("hasRole('ADMIN')")
@PatchMapping("/users/{id}/deactivate")
public ResponseEntity<String> deactivate(@PathVariable Long id) {

    User user = userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

    user.setActive(false);
    userRepository.save(user);

    return ResponseEntity.ok("Usuário desativado");
}


}